# Ticket Management System
#### Video Demo: <https://youtu.be/417_J_yJ5uI>
#### Description: 

###### What is a managemnt system?

From the Yellow Pages and household inventory to employee records for businesses, databases are more efficient and flexible than other methods for storing and retrieving your valuable information. Databases are computer programs or software used to store, organize and report information. All the information in databases must fit into specified categories or fields. This feature is one of the key advantages of using databases; it gives you multiple options for organizing and analyzing your records. A management system is the way in which an organization manages the interrelated parts of its business in order to achieve its objectives. These objectives can relate to a number of different topics, including product or service quality, operational efficiency, environmental performance, health and safety in the workplace and many more.

The level of complexity of the system will depend on each organization’s specific context. For some organizations, especially smaller ones, it may simply mean having strong leadership from the business owner, providing a clear definition of what is expected from each individual employee and how they contribute to the organization’s overall objectives, without the need for extensive documentation. More complex businesses operating, for example, in highly regulated sectors, may need extensive documentation and controls in order to fulfil their legal obligations and meet their organizational objectives


### My management system.
Its a ticket managemnt system which will allow users to transition from traditional methods of keeping databases to more modern ones. This project was created using python spider. Once the user executes the code and fills in the required details it coneverts all the data into a CSV file. This project i beleive is a stepping stone into the digital world for many existing fields.


### **These are the steps used into creating my project.**
*1. I started out with exporting The CSV and Random Modules 

*Program Code:*
#imports the csv module so we can write data to csv import csv 
import csv 
#imports the random module so we can generate a random number import random
import random 
#makes a 2D array called bookings. This is where the collected data #is going to go before it gets written to the csv file 
bookings = []

2. The 'random' module helps with giving random booking numbers to users. 

3. I Made input commands so that the user can input his/her data 

*Program Code:* 
surname = input ("Please enter your surname: ")
forename = input ("Please enter your forename: ")
film = input ("Please enter the film you want to see: ")
day = input ("What day of the week do you want to see the film?: ")

4. And once all the data was inputted i wrote a code that converted all the data into a csv file (This CSV file would be stored in the same location as the main program i.e in my video it was on the desktop)
5. For the confirmation i just displayed a thank you message along with the customers data.*



#### Images:

./project/Screen Shot 2021-11-20 at 1.21.35 PM.png
./project/Screen Shot 2021-11-20 at 1.37.42 PM.png


For the video deomstration visit: [YOUTUBE](https://youtu.be/417_J_yJ5uI).


Thank You. 
CS50

