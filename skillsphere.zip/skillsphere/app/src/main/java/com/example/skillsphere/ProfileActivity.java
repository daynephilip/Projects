package com.example.skillsphere;

import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

public class ProfileActivity extends AppCompatActivity {

    private TextView firstNameTextView;
    private TextView emailTextView;
    private TextView skillsTextView;
    private ImageView profileImageView;
    private Button selectImageButton;
    private BottomNavigationView bottomNavigationView;

    private FirebaseStorage storage;
    private StorageReference storageRef;

    private static final int PICK_IMAGE_REQUEST = 1;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);


        storage = FirebaseStorage.getInstance();
        storageRef = storage.getReference();

        firstNameTextView = findViewById(R.id.firstNameTextView);
        emailTextView = findViewById(R.id.emailTextView);
        skillsTextView = findViewById(R.id.skillsTextView);
        profileImageView = findViewById(R.id.profileImageView);
        selectImageButton = findViewById(R.id.selectPhotoButton);
        bottomNavigationView = findViewById(R.id.bottom_navigation);

        SharedPreferences sharedPreferences = getSharedPreferences("UserDetails", MODE_PRIVATE);
        String firstName = sharedPreferences.getString("firstName", "");
        String email = sharedPreferences.getString("email", "");
        String skills = sharedPreferences.getString("skills", "");


        firstNameTextView.setText(firstName);
        emailTextView.setText(email);
        skillsTextView.setText(skills);


        selectImageButton.setOnClickListener(v -> openImagePicker());


        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.navigation_home) {
                startActivity(new Intent(ProfileActivity.this, home.class));
                finish();
                return true;
            } else if (itemId == R.id.navigation_profile) {

                return true;
            } else if (itemId == R.id.navigation_chat) {
                startActivity(new Intent(ProfileActivity.this, chat.class)); // Start ChatActivity
                finish();
                return true;
            } else if (itemId == R.id.navigation_settings) {
                startActivity(new Intent(ProfileActivity.this, SettingsActivity.class)); // Start SettingsActivity
                finish();
                return true;
            }
            return false;
        });
    }

    private void openImagePicker() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();

            profileImageView.setImageURI(imageUri);
            uploadImageToFirebaseStorage(imageUri);
        }
    }

    private void uploadImageToFirebaseStorage(Uri imageUri) {

        StorageReference profileImageRef = storageRef.child("profile.jpg");

        profileImageRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> {

                    Toast.makeText(ProfileActivity.this, "Image Uploaded to Firebase", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {

                    Toast.makeText(ProfileActivity.this, "Failed to upload image: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }
}
