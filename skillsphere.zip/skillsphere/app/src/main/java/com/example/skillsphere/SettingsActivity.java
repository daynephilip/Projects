package com.example.skillsphere;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar; // Import for Toolbar
import com.google.android.material.bottomnavigation.BottomNavigationView; // Import for BottomNavigationView
import com.example.skillsphere.R; // Import for R class

public class SettingsActivity extends AppCompatActivity {
    // Constants for navigation item IDs
    private static final int NAVIGATION_HOME = R.id.navigation_home;
    private static final int NAVIGATION_PROFILE = R.id.navigation_profile;
    private static final int NAVIGATION_CHAT = R.id.navigation_chat;
    private static final int NAVIGATION_SETTINGS = R.id.navigation_settings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        ImageView hamburgerMenu = findViewById(R.id.hamburger_menu);
        hamburgerMenu.setOnClickListener(v -> {
            Intent intent = new Intent(SettingsActivity.this, AboutUsActivity.class);
            startActivity(intent);
        });

        setupBottomNavigation();
    }

    private void setupBottomNavigation() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == NAVIGATION_HOME) {
                startActivity(new Intent(SettingsActivity.this, home.class)); // Start HomeActivity
                finish();
                return true;
            } else if (itemId == NAVIGATION_PROFILE) {
                startActivity(new Intent(SettingsActivity.this, ProfileActivity.class)); // Start ProfileActivity
                finish();
                return true;
            } else if (itemId == NAVIGATION_CHAT) {
                startActivity(new Intent(SettingsActivity.this, chat.class)); // Start ChatActivity
                finish();
                return true;
            } else if (itemId == NAVIGATION_SETTINGS) {
                // Already on the settings screen, no need to do anything
                return true;
            }
            return false;
        });

        // Set the current item as settings
        bottomNavigationView.setSelectedItemId(NAVIGATION_SETTINGS);
    }
}
