package com.example.skillsphere;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.firestore.FirebaseFirestore;

public class home extends AppCompatActivity {

    private FirebaseFirestore db;
    private LinearLayout skillsList;

    // Constants for navigation item IDs
    private static final int NAVIGATION_HOME = R.id.navigation_home;
    private static final int NAVIGATION_PROFILE = R.id.navigation_profile;
    private static final int NAVIGATION_CHAT = R.id.navigation_chat;
    private static final int NAVIGATION_SETTINGS = R.id.navigation_settings;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        db = FirebaseFirestore.getInstance();

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Retrieve the user name from the Intent
        String userName = getIntent().getStringExtra("USER_NAME");
        TextView welcomeMessage = findViewById(R.id.welcome_message);
        if (userName != null && !userName.isEmpty()) {
            welcomeMessage.setText("Hello, " + userName);
        } else {
            welcomeMessage.setText("Hello, User");
        }

        skillsList = findViewById(R.id.skills_list);

        setupBottomNavigation();
        setupSkillsList();
        loadRegisteredProfiles();

        ImageView hamburgerMenu = findViewById(R.id.hamburger_menu);
        hamburgerMenu.setOnClickListener(v -> {
            // Handle the hamburger menu click event
            Intent intent = new Intent(home.this, AboutUsActivity.class);
            startActivity(intent);
        });
    }

    @SuppressLint("NonConstantResourceId")
    private void setupBottomNavigation() {
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == NAVIGATION_HOME) {
                return true;
            } else if (itemId == NAVIGATION_PROFILE) {
                startActivity(new Intent(home.this, ProfileActivity.class));
                return true;
            } else if (itemId == NAVIGATION_CHAT) {
                startActivity(new Intent(home.this, chat.class)); // Start ChatActivity
                return true;
            } else if (itemId == NAVIGATION_SETTINGS) {
                startActivity(new Intent(home.this, SettingsActivity.class)); // Start SettingsActivity
                return true;
            }
            return false;
        });

        // Set the default selected item as home
        bottomNavigationView.setSelectedItemId(NAVIGATION_HOME);

        // Set listener for re-selecting the home icon
        bottomNavigationView.setOnItemReselectedListener(item -> {
            if (item.getItemId() == NAVIGATION_HOME) {
                // Already on the home screen, no need to do anything
                return;
            }

            Intent intent = new Intent(home.this, home.class);
            startActivity(intent);
            finish();
        });
    }

    private void setupSkillsList() {
        TextView skillFishing = findViewById(R.id.skill_fishing);
        TextView skillBoxing = findViewById(R.id.skill_boxing);
        TextView skillCooking = findViewById(R.id.skill_cooking);
        TextView skillCoding = findViewById(R.id.skill_coding);
        TextView skillNetworking = findViewById(R.id.skill_networking);
        TextView skillMarketing = findViewById(R.id.skill_marketing);


        skillFishing.setOnClickListener(v -> {

        });

        skillBoxing.setOnClickListener(v -> {

        });

        skillCooking.setOnClickListener(v -> {

        });

        skillCoding.setOnClickListener(v -> {

        });

        skillNetworking.setOnClickListener(v -> {

        });

        skillMarketing.setOnClickListener(v -> {

        });
    }

    private void loadRegisteredProfiles() {

    }
}
